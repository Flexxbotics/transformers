﻿$ErrorActionPreference = "Continue"

# Simple logging helpers
function Log([string]$msg)    { "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" | Out-File -Append "C:\ProgramData\FlexxScripts\logs\agent.out.log" }
function LogErr([string]$msg) { "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" | Out-File -Append "C:\ProgramData\FlexxScripts\logs\agent.err.log" }

# Discover Python: prefer venv in the same folder as this script; else 'py'; else 'python'
function Get-Python {
  $venv = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
  if (Test-Path $venv) { return $venv }
  if (Get-Command py -ErrorAction SilentlyContinue) { return "py" }
  return "python"
}

while ($true) {
  try {
    $python = Get-Python
    $agent  = Join-Path $PSScriptRoot "script_executor_agent.py"
    $cwd    = $PSScriptRoot

    Log "[Wrapper] CWD: '$cwd'"
    Log "[Wrapper] Python: $python"
    try {
      if ($python -eq "py") { $pv = (& py -3 -c 'import sys;print(sys.version)' 2>&1) }
      else                  { $pv = (& $python -c 'import sys;print(sys.version)' 2>&1) }
      if ($pv) { Log "[Wrapper] Python version: $pv" }
    } catch {}

    # Build arguments safely (arrays avoid quoting issues)
    if ($python -eq "py") {
      $file = "py"
      $args = @("-3","-u", $agent)
    } else {
      $file = $python
      $args = @("-u", $agent)
    }

    Log "[Wrapper] Starting agent: $file $($args -join ' ')"
    $proc = Start-Process -FilePath $file -ArgumentList $args -WorkingDirectory $cwd -NoNewWindow -PassThru
    Log "[Wrapper] Agent PID: $($proc.Id)"

    Wait-Process -Id $proc.Id
    $exit = try { $proc.ExitCode } catch { -1 }
    Log "[Wrapper] Agent PID $($proc.Id) exited with code $exit"
  } catch {
    LogErr "[Wrapper ERROR] $($_ | Out-String)"
  }

  Log "[Wrapper] Restarting agent in 5s..."
  Start-Sleep -Seconds 5
}
