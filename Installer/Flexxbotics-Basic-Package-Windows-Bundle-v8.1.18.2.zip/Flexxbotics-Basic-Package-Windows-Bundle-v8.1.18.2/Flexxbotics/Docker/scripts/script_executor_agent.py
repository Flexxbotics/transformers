import os
import time
import subprocess
from pathlib import Path

# === CONFIGURATION ===
BASE_DIR = Path(__file__).parent.resolve()  # Automatically use current folder
WATCH_FOLDER = BASE_DIR / "ScriptQueue"
SCRIPT_FOLDER = BASE_DIR

POLL_INTERVAL = 1  # seconds

def log(msg):
    print(f"[ScriptAgent] {msg}")

def run():
    log(f"Watching for scripts in: {WATCH_FOLDER}")
    WATCH_FOLDER.mkdir(parents=True, exist_ok=True)

    while True:
        task_files = list(WATCH_FOLDER.glob("*.task"))
        for task_file in task_files:
            try:
                with task_file.open("r") as f:
                    script_name = f.read().strip()

                script_path = SCRIPT_FOLDER / script_name

                if not script_path.exists():
                    log(f"Script not found: {script_path}")
                else:
                    log(f"Executing: {script_path}")
                    subprocess.Popen(["python", str(script_path)], shell=True)

                task_file.unlink()  # Remove task file

            except Exception as e:
                log(f"Error processing {task_file.name}: {e}")
        time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    run()
